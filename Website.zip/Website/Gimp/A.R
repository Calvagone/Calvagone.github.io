library(campsis)
library(ggplot2)

model <- model_library$advan2_trans2
model <- model %>% replace(Theta(name="CL", value=10))
model <- model %>% add(Omega(name="Init", value=0.001))
model <- model %>% add(InitialCondition(compartment=2, rhs="(0.1 + ETA_INIT)*80"))

ds <- Dataset(8) %>% 
  add(Infusion(time=0, amount=100, compartment=1, duration=10)) %>%
  add(Observations(0:24))

results <- model %>% simulate(dataset=ds, seed=12)

plot <- ggplot(results, aes_string(x="TIME", y="CP", group="ID")) + geom_line(colour="gray39", size=1) +
  theme(panel.grid.major=element_blank(), panel.grid.minor=element_blank(), panel.background=element_blank(), axis.line=element_line(colour="black"))
plot

ggsave("1cpt_A_letter.png", plot=plot, units="cm", dpi=300, width=10, height=10)