browseURL(
  xfun::in_dir(".", rmarkdown::render_site("index.Rmd"))
)

browseURL(
  xfun::in_dir(".", rmarkdown::render_site("intro.Rmd"))
)

browseURL(
  xfun::in_dir(".", rmarkdown::render_site("install.Rmd"))
)

browseURL(
  xfun::in_dir(".", rmarkdown::render_site("get_started.Rmd"))
)

browseURL(
  xfun::in_dir(".", rmarkdown::render_site("ecampsis.Rmd"))
)

# browseURL(
#   xfun::in_dir(".", rmarkdown::render_site("workshop_page.Rmd"))
# )

browseURL(
  xfun::in_dir(".", rmarkdown::render_site("news.Rmd"))
)

browseURL(
  xfun::in_dir(".", rmarkdown::render_site("contact.Rmd"))
)